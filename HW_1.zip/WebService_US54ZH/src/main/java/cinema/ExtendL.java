package cinema;

import seatreservation.*;

public class ExtendL extends Lock {
	
	private String id;
	
	public ExtendL(Seat seat, int count) {
		super();
		setSeat(seat);
		setCount(count);
		this.id = seat.getRow() + ':' + seat.getColumn() + ':' + getCount();
	}
	
	public String getId() {
		return id;
	}

}