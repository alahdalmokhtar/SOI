package cinema;

import javax.xml.ws.BindingProvider;
import seatreservation.*;


public class Program {
	public static void main(String[] args) {
		String url = args[0];
		String row = args[1];
		String column = args[2];
		String task = args[3];
		
		CinemaService cim = new CinemaService();
		ICinema clint = cim.getICinemaHttpSoap11Port();
		BindingProvider binding = (BindingProvider) clint;
		binding.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, url);
		
		try {
			String lockId;
			Seat seat = new Seat();
			seat.setRow(row);
			seat.setColumn(column);
			
			switch(task) {
				case "Lock": 
					lockId = clint.lock(seat, 1);
					System.out.println("Seat locked.");
					break;
					
				case "Reserve": 
					lockId = clint.lock(seat, 1);
					clint.reserve(lockId);
					System.out.println("Seat reserved.");
					break;
					
				case "Buy": 
					lockId = clint.lock(seat, 1);
					clint.buy(lockId);
					System.out.println("Seat bought.");
					break;
			}
		} catch (ICinemaLockCinemaException e) {
			e.printStackTrace();
		} catch (ICinemaReserveCinemaException e) {
			e.printStackTrace();
		} catch (ICinemaBuyCinemaException e) {
			e.printStackTrace();
		}

}
}

