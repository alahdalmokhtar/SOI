package seatreservation;

public enum SeatStatus {
	FREE,
	LOCKED,
	RESERVED
}
